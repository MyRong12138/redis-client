use ferris_says::say; // from the previous step
use std::io::{stdout, BufWriter};
use std::collections::{ BTreeMap };
use std::{thread, time};

extern crate redis_client;
use redis_client::RedisClient;

extern crate mysql;
use mysql as my;

extern crate redis;
use redis::Commands;

#[derive(Debug, PartialEq, Eq)]
struct Payment {
    tenant_id: i32,
    shop_id: i32,
    user_id: i32,
}

fn main() {
    let stdout = stdout();
    let out = b"Hello fellow Rustaceans!";
    let width = 24;
    let mut writer = BufWriter::new(stdout.lock());
    say(out, width, &mut writer).unwrap();
    println!("开始");
    //fetch_an_integer();
   // println!("{}", redis);
   
   
//不用库，获取消息队列有问题
   /*
   //输入插入redis
   //let sock_addr: &str = "192.168.43.111:6379";
   let sock_addr: &str = "192.168.43.111:6379";
   let mut client = RedisClient::new(sock_addr);
   client.auth("root");
   println!("redis登录成功");
   //string
   //client.set("stringName", "stringDate");
   //println!("{}", client.get("stringName"));

   //获取消息队列的消息
   let listMessageDate: Vec<String>=client.xread("userInfo","0-0");
   for i in listMessageDate {
     println!("获取的消息队列的值为：{}", i);
 }
*/

  selectRedis();

  let mut s = String::from("0-0");

   //无限循环
   loop {
    //println!("again!");
    getMessage(&mut s);
    println!("{}",s);
}



//用库
   // redis::cmd("AUTH").arg("root").execute(&mut con);
   
}
//查询Redis数据库是否为空
fn selectRedis() -> redis::RedisResult<()> {
    let sock_addr: &str = "192.168.43.111:6379";
    let mut client = RedisClient::new(sock_addr);
    client.auth("root");
    let message=client.exists("name");

    if message=="1" 
    {
    println!("返回信息为：{}",message);
    }
    else {
        getAllMysql();
    }
    /* do something here */
    Ok(())
}

//数据插入redis
fn inseartMessage(userId: &str,userDate: &str) -> redis::RedisResult<()> {
    let client = redis::Client::open("redis://192.168.43.111/")?;
    let mut con = client.get_connection()?;
    redis::cmd("AUTH").arg("root").query(&mut con)?;
    redis::cmd("HSET").arg("name").arg(userId).arg(userDate).query(&mut con)?;
    
    /* do something here */
    println!("redis数据插入成功");
    Ok(())
}
//获取消息队列消息
fn getMessage( messageId: &mut String) -> redis::RedisResult<()> {
    let client = redis::Client::open("redis://192.168.43.111/")?;
    let mut con = client.get_connection()?;
    redis::cmd("AUTH").arg("root").query(&mut con)?;
    let message : Vec<Vec<(String, Vec<BTreeMap<String, Vec<(String, String)>>>)>> =redis::cmd("xread").arg("count").arg("1").arg("streams").arg("userInfo").arg(messageId.as_str()).query(&mut con)?;
    
    /* do something here */
    println!("redis数据获取成功");
    if message.len() > 0 {
        //let mut messageId = String::new();
        println!("获取的数据为：{:#?}",message.get(0).unwrap().get(0).unwrap().1);
        let item = &message[0][0];
        for i in &item.1 {
            for (k, v) in i {
                println!("key为:{} - value为:{:#?}", k, v);
                *messageId=k.to_string();
                let userId=&v.get(1).unwrap().1;
                println!("用户id为{}",userId);
                getMysql(userId);
                return getMessage(messageId);
            }
        }
    }
    else {
        let ten_millis = time::Duration::from_millis(10000);
        let now = time::Instant::now();
        println!("消息队列已空，程序休眠中，10s，最后一个消息id为\n{}",messageId);
        thread::sleep(ten_millis);
        //let mesId=messageId;
        //return getMessage(mesId);
    }
    

    Ok(())
}
//获取mysql单条数据，并插入redis
fn getMysql( userId: &str){
//连接mysql
   //*
   let pool = my::Pool::new("mysql://root:root@10.33.250.220:3306/shby_tenant").unwrap();
   print!("************************mysql连接成功***********************************");

  let selected_payments: Vec<Payment> =
  pool.prep_exec("select tenant_id,shop_id,user_id from tenant_hierarchy where user_id=61002853", ())
  .map(|result| { 
      result.map(|x| x.unwrap()).map(|row| {
          //数据映射
        let (tenant_id, shop_id,user_id) = my::from_row(row);
        Payment {
            tenant_id: tenant_id,
            shop_id: shop_id,
            user_id: user_id,
        }
      }).collect() 
  }).unwrap(); 

  println!("{:#?}",selected_payments);


  println!("{}",selected_payments.get(0).unwrap().tenant_id);
  println!("Yay!");


  let mut str="".to_string();
   str.push_str("tenant_id");
   str.push_str(&selected_payments.get(0).unwrap().tenant_id.to_string());
   str.push_str("shop_id");
   str.push_str(&selected_payments.get(0).unwrap().shop_id.to_string());
   str.push_str("*");
   inseartMessage(userId,str.as_str());

}

//获取mysql全部数据，并插入redis
fn getAllMysql(){
    //连接mysql
       //*
       let pool = my::Pool::new("mysql://root:root@10.33.250.220:3306/shby_tenant").unwrap();
       print!("************************mysql连接成功***********************************");
    
      let selected_payments: Vec<Payment> =
      pool.prep_exec("select tenant_id,shop_id,user_id from tenant_hierarchy", ())
      .map(|result| { 
          result.map(|x| x.unwrap()).map(|row| {
              //数据映射
            let (tenant_id, shop_id,user_id) = my::from_row(row);
            Payment {
                tenant_id: tenant_id,
                shop_id: shop_id,
                user_id: user_id,
            }
          }).collect() 
      }).unwrap(); 
    
      println!("{:#?}",selected_payments);
    
      for i in selected_payments {
        println!("{}",i.tenant_id);
        let mut str="".to_string();
        str.push_str("tenant_id");
        str.push_str(&i.tenant_id.to_string());
        str.push_str("shop_id");
        str.push_str(&i.shop_id.to_string());
        str.push_str("*");
        inseartMessage(&i.user_id.to_string(),str.as_str());
      }
      println!("Yay!");
    
    }